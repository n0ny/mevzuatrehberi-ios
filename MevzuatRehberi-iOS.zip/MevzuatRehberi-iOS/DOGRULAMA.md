# Yerel doğrulama

Kaynak: C:/AndroidProjects/mevzuatrehberi.zip
Tarih: 9 Ekim 2026

## Geçen yapısal kontroller

- Android MainActivity.java, AndroidManifest.xml, Gradle uygulama yapılandırması ve simge kaynakları incelendi.
- Info.plist ve PrivacyInfo.xcprivacy standart plist ayrıştırıcısı ile doğrulandı.
- LaunchScreen.storyboard ve ortak Xcode scheme XML olarak ayrıştırıldı.
- Xcode projesindeki bütün nesne kimlikleri çözümlendi, başvurular ve parantez dengesi kontrol edildi.
- Dört uygulama Swift kaynağı, test kaynağı ve uygulama kaynak dosyaları mevcut.
- 18 iPhone, iPad ve mağaza simgesinin ölçüleri ve opak RGB biçimi doğrulandı.
- XCTest hedefi ve ortak scheme içindeki test hedefi eşleşiyor.
- HTTPS taşıma güvenliğini gevşeten Info.plist istisnası yok.
- Sekiz gezinme politikası test yöntemi hazırlandı.
- Teslim ZIP'i CRC kontrolünden geçti.

## Henüz çalıştırılmayan kontroller

- Xcode / iOS SDK ile derleme: Windows ortamında mümkün olmadığı için çalıştırılmadı.
- XCTest testleri: Mac simülatörü gerektirdiği için çalıştırılmadı.
- Siteye canlı giriş ve fiziksel iPhone testleri: çalıştırılmadı.
- Bulut derleme akışı: hazırlandı, ancak GitHub hesabı / uzak depo bağlantısı olmadan çalıştırılmadı.
- İmzalı IPA üretme ve iPhone'a kurulum: Apple hesabıyla imzalama aşaması tamamlanmadı.

Bu rapor uygulamanın derlendiği veya telefonda çalıştığı anlamına gelmez. Gerçek derleme ve test sonuçları GitHub Actions işinin çıktısı veya Xcode ile doğrulanmalıdır.
