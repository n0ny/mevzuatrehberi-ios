import Foundation

enum NavigationDecision: Equatable {
    case allow
    case external(URL)
    case block
}

enum NavigationPolicy {
    static let homeURL = URL(string: "https://sg.barisguresci.com.tr/")!
    static let allowedHost = "sg.barisguresci.com.tr"

    static func isInternal(_ url: URL) -> Bool {
        url.scheme?.lowercased() == "https"
            && url.host?.lowercased() == allowedHost
            && (url.port == nil || url.port == 443)
            && url.user == nil && url.password == nil
    }

    static func decide(_ url: URL, isMainFrame: Bool, isUserInitiated: Bool) -> NavigationDecision {
        let scheme = url.scheme?.lowercased() ?? ""
        if isInternal(url) { return .allow }
        // Frame content never launches another application.
        if !isMainFrame {
            return scheme == "https" || url.absoluteString == "about:blank" ? .allow : .block
        }
        // Redirects and scripts must not launch apps or Safari automatically.
        guard isUserInitiated else { return .block }
        switch scheme {
        case "https", "http":
            guard url.host != nil, url.user == nil, url.password == nil else { return .block }
            // The Android manifest also disallows cleartext access to the app's own site.
            if url.host?.lowercased() == allowedHost && scheme == "http" { return .block }
            return .external(url)
        case "tel", "mailto":
            return .external(url)
        case "geo":
            guard let mapsURL = mapsURL(from: url) else { return .block }
            return .external(mapsURL)
        default:
            return .block
        }
    }

    private static func mapsURL(from url: URL) -> URL? {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        var maps = URLComponents()
        maps.scheme = "https"
        maps.host = "maps.apple.com"
        let query = components.queryItems?.first(where: { $0.name == "q" })?.value
        let location = query?.isEmpty == false ? query! : components.path
        guard !location.isEmpty else { return nil }
        maps.queryItems = [URLQueryItem(name: "q", value: location)]
        return maps.url
    }
}
