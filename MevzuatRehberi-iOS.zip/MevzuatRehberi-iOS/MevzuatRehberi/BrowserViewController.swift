import UIKit
import WebKit
import Network

final class BrowserViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private let navy = UIColor(red: 2 / 255, green: 9 / 255, blue: 31 / 255, alpha: 1)
    private var webView: WKWebView!
    private let progress = UIProgressView(progressViewStyle: .default)
    private let toolbar = UIToolbar()
    private let errorPanel = UIView()
    private let errorTitle = UILabel()
    private let errorMessage = UILabel()
    private let monitor = NWPathMonitor()
    private var observations: [NSKeyValueObservation] = []
    private var networkAvailable: Bool?
    private var hasError = false
    private var lastRequestedURL = NavigationPolicy.homeURL
    private var backItem: UIBarButtonItem!
    private var forwardItem: UIBarButtonItem!
    private var shareItem: UIBarButtonItem!

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        configureWebView()
        buildInterface()
        observeBrowser()
        monitor.pathUpdateHandler = { [weak self] path in
            let available = path.status == .satisfied
            DispatchQueue.main.async {
                guard let self = self else { return }
                let previous = self.networkAvailable
                self.networkAvailable = available
                if !available {
                    self.webView.stopLoading()
                    self.showError(offline: true)
                } else if previous == false && self.hasError {
                    self.retry()
                }
            }
        }
        monitor.start(queue: DispatchQueue(label: "com.barisguresci.sgmevzuat.network"))
        webView.load(URLRequest(url: NavigationPolicy.homeURL))
    }

    private func configureWebView() {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.applicationNameForUserAgent = "MevzuatRehberi/2.0 iOS"
        configuration.mediaTypesRequiringUserActionForPlayback = .all
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = .white
        webView.scrollView.backgroundColor = .white
        // Keep the webpage's own viewport and zoom/accessibility behavior.
    }

    private func buildInterface() {
        view.backgroundColor = navy
        progress.progressTintColor = UIColor(red: 10 / 255, green: 132 / 255, blue: 1, alpha: 1)
        progress.trackTintColor = navy
        progress.isHidden = true
        toolbar.tintColor = .white
        let appearance = UIToolbarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = navy
        toolbar.standardAppearance = appearance
        toolbar.scrollEdgeAppearance = appearance
        backItem = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain,
                                   target: self, action: #selector(goBack))
        backItem.accessibilityLabel = "Önceki sayfa"
        forwardItem = UIBarButtonItem(image: UIImage(systemName: "chevron.right"), style: .plain,
                                      target: self, action: #selector(goForward))
        forwardItem.accessibilityLabel = "Sonraki sayfa"
        let homeItem = UIBarButtonItem(image: UIImage(systemName: "house"), style: .plain,
                                      target: self, action: #selector(goHome))
        homeItem.accessibilityLabel = "Ana sayfa"
        let refreshItem = UIBarButtonItem(barButtonSystemItem: .refresh, target: self,
                                         action: #selector(retry))
        refreshItem.accessibilityLabel = "Yenile"
        shareItem = UIBarButtonItem(barButtonSystemItem: .action, target: self,
                                   action: #selector(sharePage))
        shareItem.accessibilityLabel = "Sayfayı paylaş"
        toolbar.items = [
            backItem, UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), forwardItem, UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), homeItem,
            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), refreshItem, UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), shareItem
        ]
        [webView!, progress, toolbar, errorPanel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview($0)
        }
        NSLayoutConstraint.activate([
            progress.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            progress.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            progress.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            progress.heightAnchor.constraint(equalToConstant: 3),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolbar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: 44),
            webView.topAnchor.constraint(equalTo: progress.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: toolbar.topAnchor),
            errorPanel.topAnchor.constraint(equalTo: progress.bottomAnchor),
            errorPanel.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            errorPanel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            errorPanel.bottomAnchor.constraint(equalTo: toolbar.topAnchor)
        ])
        errorPanel.backgroundColor = navy
        errorPanel.isHidden = true
        errorTitle.font = .preferredFont(forTextStyle: .title2)
        errorTitle.textColor = .white
        errorTitle.textAlignment = .center
        errorTitle.numberOfLines = 0
        errorTitle.adjustsFontForContentSizeCategory = true
        errorMessage.font = .preferredFont(forTextStyle: .body)
        errorMessage.textColor = .lightGray
        errorMessage.textAlignment = .center
        errorMessage.numberOfLines = 0
        errorMessage.adjustsFontForContentSizeCategory = true
        var buttonConfiguration = UIButton.Configuration.filled()
        buttonConfiguration.title = "Tekrar Dene"
        buttonConfiguration.baseBackgroundColor = .systemBlue
        buttonConfiguration.cornerStyle = .medium
        let retryButton = UIButton(configuration: buttonConfiguration)
        retryButton.addTarget(self, action: #selector(retry), for: .touchUpInside)
        let stack = UIStackView(arrangedSubviews: [errorTitle, errorMessage, retryButton])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        errorPanel.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: errorPanel.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: errorPanel.leadingAnchor, constant: 28),
            stack.trailingAnchor.constraint(equalTo: errorPanel.trailingAnchor, constant: -28),
            errorTitle.widthAnchor.constraint(equalTo: stack.widthAnchor),
            errorMessage.widthAnchor.constraint(equalTo: stack.widthAnchor)
        ])
        updateControls()
    }

    private func observeBrowser() {
        observations = [
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] _, _ in
                guard let self = self else { return }
                self.progress.setProgress(Float(self.webView.estimatedProgress), animated: true)
            },
            webView.observe(\.canGoBack, options: [.new]) { [weak self] _, _ in self?.updateControls() },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] _, _ in self?.updateControls() }
        ]
    }

    private func updateControls() {
        backItem.isEnabled = webView.canGoBack && !hasError
        forwardItem.isEnabled = webView.canGoForward && !hasError
        shareItem.isEnabled = webView.url != nil && !hasError
    }

    private func beginLoading() {
        hasError = false
        errorPanel.isHidden = true
        webView.isHidden = false
        progress.progress = 0
        progress.isHidden = false
        updateControls()
    }

    private func showError(offline: Bool) {
        hasError = true
        progress.isHidden = true
        webView.isHidden = true
        errorPanel.isHidden = false
        errorTitle.text = offline ? "İnternet bağlantısı yok" : "Sayfa yüklenemedi"
        errorMessage.text = offline
            ? "Mevzuat Rehberi'ne bağlanmak için internet bağlantınızı kontrol edin."
            : "Sunucuya şu anda ulaşılamıyor. Biraz sonra tekrar deneyin."
        updateControls()
    }

    @objc private func retry() {
        guard networkAvailable != false else { showError(offline: true); return }
        beginLoading()
        if webView.url == lastRequestedURL {
            webView.reload()
        } else {
            webView.load(URLRequest(url: lastRequestedURL))
        }
    }

    @objc private func goBack() { webView.goBack() }
    @objc private func goForward() { webView.goForward() }
    @objc private func goHome() {
        lastRequestedURL = NavigationPolicy.homeURL
        retry()
    }

    @objc private func sharePage() {
        guard let url = webView.url, NavigationPolicy.isInternal(url) else { return }
        let controller = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        controller.popoverPresentationController?.barButtonItem = shareItem
        present(controller, animated: true)
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let isMainFrame = action.targetFrame?.isMainFrame ?? true
        let decision = NavigationPolicy.decide(url, isMainFrame: isMainFrame,
                                              isUserInitiated: action.navigationType == .linkActivated)
        switch decision {
        case .allow:
            if isMainFrame { lastRequestedURL = url }
            decisionHandler(.allow)
        case .external(let url):
            decisionHandler(.cancel)
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        case .block:
            decisionHandler(.cancel)
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if response.isForMainFrame {
            if let http = response.response as? HTTPURLResponse, http.statusCode >= 500 {
                decisionHandler(.cancel)
                showError(offline: networkAvailable == false)
                return
            }
            if !response.canShowMIMEType {
                decisionHandler(.cancel)
                hasError = true
                progress.isHidden = true
                errorTitle.text = "Bu dosya uygulamada açılamıyor"
                errorMessage.text = "Dosyayı Safari üzerinden açıp indirebilirsiniz."
                webView.isHidden = true
                errorPanel.isHidden = false
                updateControls()
                offerSafari(for: response.response.url)
                return
            }
        }
        decisionHandler(.allow)
    }

    private func offerSafari(for url: URL?) {
        guard let url = url, NavigationPolicy.isInternal(url) else { return }
        let alert = UIAlertController(title: "Dosyayı aç",
                                      message: "Dosya bağlantısı Safari'de açılsın mı?",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "İptal", style: .cancel))
        alert.addAction(UIAlertAction(title: "Safari'de Aç", style: .default) { _ in
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if networkAvailable == false {
            webView.stopLoading()
            showError(offline: true)
        } else {
            beginLoading()
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard !hasError, networkAvailable != false else { return }
        progress.isHidden = true
        if let url = webView.url, NavigationPolicy.isInternal(url) { lastRequestedURL = url }
        updateControls()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handleFailure(error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        handleFailure(error)
    }

    private func handleFailure(_ error: Error) {
        let nsError = error as NSError
        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorCancelled { return }
        showError(offline: networkAvailable == false
                  || (nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet))
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { retry() }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // Internal target="_blank" links open in the current browser.
        if action.targetFrame == nil, let url = action.request.url, NavigationPolicy.isInternal(url) {
            webView.load(action.request)
        }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard presentedViewController == nil else { completionHandler(); return }
        let alert = UIAlertController(title: "Mevzuat Rehberi", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Tamam", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard presentedViewController == nil else { completionHandler(false); return }
        let alert = UIAlertController(title: "Mevzuat Rehberi", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "İptal", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "Tamam", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        guard presentedViewController == nil else { completionHandler(nil); return }
        let alert = UIAlertController(title: "Mevzuat Rehberi", message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "İptal", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "Tamam", style: .default) { [weak alert] _ in
            completionHandler(alert?.textFields?.first?.text)
        })
        present(alert, animated: true)
    }

    deinit {
        monitor.cancel()
        observations.forEach { $0.invalidate() }
    }
}
