import XCTest
@testable import MevzuatRehberi

final class NavigationPolicyTests: XCTestCase {
    private func decide(_ value: String, mainFrame: Bool = true,
                        userInitiated: Bool = true) -> NavigationDecision {
        NavigationPolicy.decide(URL(string: value)!, isMainFrame: mainFrame,
                                isUserInitiated: userInitiated)
    }

    func testOwnHTTPSHostStaysInsideTheApp() {
        XCTAssertEqual(decide("https://sg.barisguresci.com.tr/giris"), .allow)
        XCTAssertEqual(decide("https://SG.BARISGURESCI.COM.TR:443/mevzuat"), .allow)
    }

    func testUntrustedHostCannotMasqueradeAsTheInternalSite() {
        for value in [
            "https://sg.barisguresci.com.tr.example.com/",
            "https://other.sg.barisguresci.com.tr/",
            "https://sg.barisguresci.com.tr@evil.example/"
        ] {
            XCTAssertFalse(NavigationPolicy.isInternal(URL(string: value)!))
        }
        XCTAssertEqual(decide("https://sg.barisguresci.com.tr@evil.example/"), .block)
    }

    func testInternalCleartextAndAlternatePortsAreNotAllowedInside() {
        XCTAssertEqual(decide("http://sg.barisguresci.com.tr/"), .block)
        XCTAssertFalse(NavigationPolicy.isInternal(URL(string: "https://sg.barisguresci.com.tr:8443/")!))
    }

    func testExternalLinkNeedsAUserGesture() {
        let url = URL(string: "https://www.mevzuat.gov.tr/")!
        XCTAssertEqual(decide(url.absoluteString), .external(url))
        XCTAssertEqual(decide(url.absoluteString, userInitiated: false), .block)
    }

    func testTelephoneAndEmailOpenOnlyForUserLinks() {
        for value in ["tel:+905551234567", "mailto:destek@example.com"] {
            XCTAssertEqual(decide(value), .external(URL(string: value)!))
            XCTAssertEqual(decide(value, userInitiated: false), .block)
            XCTAssertEqual(decide(value, mainFrame: false), .block)
        }
    }

    func testGeoLinksBecomeAppleMapsLinks() {
        let decision = decide("geo:0,0?q=Ankara")
        guard case .external(let url) = decision else { return XCTFail("Expected Apple Maps URL") }
        XCTAssertEqual(url.host, "maps.apple.com")
        XCTAssertEqual(URLComponents(url: url, resolvingAgainstBaseURL: false)?
            .queryItems?.first(where: { $0.name == "q" })?.value, "Ankara")
        guard case .external(let coordinates) = decide("geo:39.9334,32.8597") else {
            return XCTFail("Expected coordinate URL")
        }
        XCTAssertEqual(URLComponents(url: coordinates, resolvingAgainstBaseURL: false)?
            .queryItems?.first?.value, "39.9334,32.8597")
    }

    func testFramesDoNotLaunchAppsAndUnsafeSchemesAreBlocked() {
        XCTAssertEqual(decide("https://example.com/frame", mainFrame: false), .allow)
        XCTAssertEqual(decide("about:blank", mainFrame: false), .allow)
        for value in ["javascript:alert(1)", "file:///etc/passwd", "intent://example", "data:text/html,hello"] {
            XCTAssertEqual(decide(value), .block)
            XCTAssertEqual(decide(value, mainFrame: false), .block)
        }
    }

    func testScriptNavigationToOwnSiteIsAllowed() {
        XCTAssertEqual(decide("https://sg.barisguresci.com.tr/", userInitiated: false), .allow)
    }
}
