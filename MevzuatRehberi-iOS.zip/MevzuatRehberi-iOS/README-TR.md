# Mevzuat Rehberi — iOS

Bu paket, paylaşılan Android Studio projesindeki Mevzuat Rehberi uygulamasının iOS kaynak uyarlamasıdır. Hazır, imzalı ve iPhone'a kurulabilir IPA değildir.

## Ne hazırlandı?

- iOS 15 ve sonrası için Swift / UIKit / WKWebView uygulaması.
- Ana adres: https://sg.barisguresci.com.tr/
- Kalıcı WebKit çerezleri ve web depolaması. Android'deki mevcut oturum telefona aktarılmaz; iOS'ta yeniden giriş yapılır. Sunucunun oturum süresi kuralları geçerlidir.
- İnternet kesildiğinde Türkçe hata ekranı, tekrar deneme ve bağlantı geri geldiğinde mevcut sayfayı yeniden yükleme.
- Sayfa yükleme göstergesi; geri / ileri / ana sayfa / yenile / paylaş araçları ve kenardan kaydırarak geri gezinme.
- Site dışındaki kullanıcı bağlantılarının Safari veya uygun uygulamada açılması. Telefon, e-posta ve geo bağlantıları.
- Açılan yeni sekmelerdeki site içi bağlantıların uygulamada açılması; JavaScript uyarı, onay ve metin giriş pencereleri.
- HTTPS ve iOS'un varsayılan taşıma güvenliği. Sunucu sertifikası denetimi kapatılmaz.
- Android paketindeki mevcut simgeden üretilmiş opak iOS simgeleri.
- Xcode projesi, ortak scheme, gezinme kuralları için XCTest testleri ve GitHub Actions Mac derleme akışı. Dış paket veya CocoaPods gerekmez.

## Windows'tan derleme

1. Bu klasörün içeriğini kendi GitHub hesabında **özel bir depoya** koyun. Özel kodu yayınlamayın; GitHub'a yükleme bu çalışma sırasında yapılmadı.
2. GitHub'da **Actions → iOS Build and Tests → Run workflow** seçin.
3. Mac çalıştırıcısındaki işlem önce iPhone simülatöründe uygulamayı derler ve testleri çalıştırır, sonra gerçek iPhone için Release derlemesi yapar.
4. İşlem başarılı olursa **MevzuatRehberi-unsigned-IPA-NEEDS-SIGNING** çıktısını indirin. İndirilen dış ZIP'i açın; içinde MevzuatRehberi-unsigned.ipa bulunur.
5. Bu IPA **imzasızdır**. Dosyayı telefona göndererek doğrudan kuramazsınız. Ayrıca Apple hesabıyla imzalanması gerekir.

Mac CI hizmetleri hesap, kota ve ücret koşulları uygulayabilir. Bu çalışma sırasında bulut derlemesi çalıştırılmadı, GitHub hesabına erişilmedi ve Apple hesabı kullanılmadı.

## Developer üyeliği olmadan kişisel test

Windows üzerinde kendi Apple hesabınızla imzalayan bir sideload aracı kullanılabilir. Örneğin AltStore Classic / AltServer veya Sideloadly; sürüm ve iOS uyumluluğunu aracı sağlayan resmi siteden kontrol edin:
- https://altstore.io/
- https://sideloadly.io/

Genel akış: bulutta üretilen imzasız IPA → Windows'taki araç ile kişisel Apple hesabınızla imzalama → USB ile iPhone'a kurulum. Araç, Apple'ın Windows bileşenleri ve telefonun bilgisayara güvenmesi gibi ek kurulumlar isteyebilir. Gerekirse iPhone'da Ayarlar → Gizlilik ve Güvenlik → Geliştirici Modu açılır ve geliştirici profiline güvenilir.

Ücretsiz kişisel imzalar genellikle **7 gün** sürer; uygulama yeniden imzalanarak yenilenmelidir. Apple ücretsiz hesaplarda uygulama / cihaz / yetenek sınırlamaları uygular. Birkaç arkadaş için her kişinin kendi hesabıyla kurması ve yenilemesi gerekir. Parolanızı bu projeye, GitHub'a veya sohbete yazmayın.

Bu yol TestFlight dağıtımı değildir; her cihazdaki kurulum ayrıca tamamlanır. Bu bilgisayarda araç kurulumu veya iPhone kurulumu denenmedi.

## Developer üyeliği alındığında

Apple Developer Program hesabı ile Xcode / bir Mac bulut derleme servisi üzerinde:
1. MevzuatRehberi.xcodeproj açılır.
2. Signing & Capabilities altında kendi Team'iniz seçilir.
3. Bundle Identifier hesabınızdaki kayda göre ayarlanır. Başlangıç kimliği com.barisguresci.sgmevzuat, sürüm 2.0.0, build 1.
4. Kayıtlı cihazlar için Ad Hoc imzalı IPA çıkarılabilir; cihaz UDID'leri profile eklenir.
5. Ya da App Store Connect'e yükleyip TestFlight üzerinden arkadaşlar davet edilir. Dış testçiler için Apple beta incelemesi gerekebilir.

Mevcut CI sadece imzasız dosya üretir. TestFlight veya Ad Hoc dağıtımı için sertifika, provisioning profile ve Apple tarafındaki kayıtlar ayrıca yapılandırılır.

## Mac erişimi olduğunda yerel doğrulama

Xcode 16 veya sonrası önerilir. Projeyi açıp iPhone simülatörü seçin; Product → Test ile testleri, Product → Run ile uygulamayı çalıştırın.

Komut satırında simülatör kimliğini kendi kurulumunuzdan seçin:

    xcrun simctl list devices available
    xcodebuild test -project MevzuatRehberi.xcodeproj -scheme MevzuatRehberi -destination 'platform=iOS Simulator,id=SIMULATOR_UDID' CODE_SIGNING_ALLOWED=NO

Cihaz için imzasız derleme:

    xcodebuild build -project MevzuatRehberi.xcodeproj -scheme MevzuatRehberi -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/Device CODE_SIGNING_ALLOWED=NO

## Telefonda kontrol edilecekler

- Açılış, giriş, mevzuat arama ve içerik sayfaları.
- Geri / ileri hareketleri, ekran döndürme ve klavye açıldığında yerleşim.
- Uygulamayı kapatıp açınca site oturumunun beklenen davranışı.
- Uçak moduna geçince hata ekranı; bağlantı geri gelince mevcut sayfaya dönüş.
- Site dışı bağlantılar, telefon, e-posta ve harita bağlantıları.
- PDF görüntüleme, site dosya yükleme / indirme akışları ve paylaşma.
- Site sunucusunun iOS Safari / WebKit desteği.

## Bilinen sınırlar

- Windows'ta Swift iOS derlemesi ve fiziksel iPhone testi yapılmadı. Dosya ve proje yapısı kontrol edildi; gerçek derleme sonucu Mac CI veya Xcode'da görülmelidir.
- Site kaynağı ZIP'te yok; paket sitenin adresini açan Android uygulamasını içeriyor. Sunucu, oturum ve site özellikleri bu paketin dışındadır.
- Siteye canlı giriş ve tüm site işlevleri test edilmedi.
- Harici kimlik sağlayıcıya yönlendiren oturum açma, başka alan adları veya JavaScript ile açılan harici pencereler varsa ayrıca uyarlanmalıdır. Ana sayfa gezinmesi tam olarak sg.barisguresci.com.tr alanıyla sınırlandırılmıştır; HTTPS alt çerçeveler site içeriğinin gerektirdiği kadar kullanılabilir.
- WebKit'in gösterebildiği PDF'ler uygulamada açılır. Gösterilemeyen dosyalarda Safari açma seçeneği sunulur. Safari uygulamanın oturum çerezlerini paylaşmaz; korumalı dosyalarda yeniden giriş gerekebilir.
- Bu uyarlama push bildirim, çevrimdışı mevzuat veritabanı, arka plan indirme veya yerel kamera işlevi eklemez; Android kaynakta bu işlevler yoktur.
- PrivacyInfo.xcprivacy yerel kabuğun mevcut davranışını tanımlar. Web sitesindeki veri toplama ve izleme incelenmedi. App Store öncesinde site davranışına göre gizlilik manifesti, gizlilik politikası ve App Store veri beyanları gözden geçirilmelidir.
- App Store kabulü garanti edilemez; ağırlıklı olarak web sitesi gösteren uygulamalar Apple'ın minimum işlevsellik değerlendirmesine tabidir.

Ayrıntılı yerel kontrol sonuçları DOGRULAMA.md dosyasındadır.
